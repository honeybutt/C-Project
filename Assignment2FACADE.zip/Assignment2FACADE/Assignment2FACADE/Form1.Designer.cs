﻿namespace Assignment2FACADE
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.chkhead = new System.Windows.Forms.CheckBox();
            this.chkHid = new System.Windows.Forms.CheckBox();
            this.chkcctv = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SalesPrice = new System.Windows.Forms.TextBox();
            this.txtShipping = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtWht = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Headset = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Hid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Cctv = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.btbContinue = new System.Windows.Forms.Button();
            this.btnSignOut = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.lblContinue = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lbltxtCarlimit = new System.Windows.Forms.Label();
            this.lblShowCardlimit = new System.Windows.Forms.Label();
            this.lbltxtCardRemainingBln = new System.Windows.Forms.Label();
            this.lblRmainingLimit = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(772, 473);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 50);
            this.button1.TabIndex = 0;
            this.button1.Text = "Check Out";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(344, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "Shopping Cart";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(104, 92);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(117, 79);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(104, 199);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(117, 69);
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(104, 299);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(117, 62);
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(241, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "HEADSET";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(241, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "HID Bulb";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(245, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "CCTV";
            // 
            // chkhead
            // 
            this.chkhead.AutoSize = true;
            this.chkhead.Location = new System.Drawing.Point(43, 112);
            this.chkhead.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkhead.Name = "chkhead";
            this.chkhead.Size = new System.Drawing.Size(30, 20);
            this.chkhead.TabIndex = 8;
            this.chkhead.Text = " ";
            this.chkhead.UseVisualStyleBackColor = true;
            this.chkhead.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chkHid
            // 
            this.chkHid.AutoSize = true;
            this.chkHid.Location = new System.Drawing.Point(43, 224);
            this.chkHid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkHid.Name = "chkHid";
            this.chkHid.Size = new System.Drawing.Size(30, 20);
            this.chkHid.TabIndex = 9;
            this.chkHid.Text = " ";
            this.chkHid.UseVisualStyleBackColor = true;
            this.chkHid.CheckedChanged += new System.EventHandler(this.chkHid_CheckedChanged);
            // 
            // chkcctv
            // 
            this.chkcctv.AutoSize = true;
            this.chkcctv.Location = new System.Drawing.Point(43, 324);
            this.chkcctv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkcctv.Name = "chkcctv";
            this.chkcctv.Size = new System.Drawing.Size(30, 20);
            this.chkcctv.TabIndex = 10;
            this.chkcctv.Text = " ";
            this.chkcctv.UseVisualStyleBackColor = true;
            this.chkcctv.CheckedChanged += new System.EventHandler(this.chkcctv_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(80, 420);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Sales Price :";
            // 
            // SalesPrice
            // 
            this.SalesPrice.Enabled = false;
            this.SalesPrice.Location = new System.Drawing.Point(267, 418);
            this.SalesPrice.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.SalesPrice.Name = "SalesPrice";
            this.SalesPrice.Size = new System.Drawing.Size(116, 21);
            this.SalesPrice.TabIndex = 12;
            this.SalesPrice.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtShipping
            // 
            this.txtShipping.Enabled = false;
            this.txtShipping.Location = new System.Drawing.Point(267, 457);
            this.txtShipping.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtShipping.Name = "txtShipping";
            this.txtShipping.Size = new System.Drawing.Size(116, 21);
            this.txtShipping.TabIndex = 13;
            this.txtShipping.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(80, 499);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "WHT TAX 7% :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(80, 459);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Shipping charges :";
            // 
            // txtWht
            // 
            this.txtWht.Enabled = false;
            this.txtWht.Location = new System.Drawing.Point(267, 497);
            this.txtWht.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtWht.Name = "txtWht";
            this.txtWht.Size = new System.Drawing.Size(116, 21);
            this.txtWht.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(626, 131);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Price";
            // 
            // Headset
            // 
            this.Headset.Enabled = false;
            this.Headset.Location = new System.Drawing.Point(754, 128);
            this.Headset.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Headset.Name = "Headset";
            this.Headset.Size = new System.Drawing.Size(116, 21);
            this.Headset.TabIndex = 18;
            this.Headset.Text = "1500";
            this.Headset.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(626, 230);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Price";
            // 
            // Hid
            // 
            this.Hid.Enabled = false;
            this.Hid.Location = new System.Drawing.Point(754, 228);
            this.Hid.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Hid.Name = "Hid";
            this.Hid.Size = new System.Drawing.Size(116, 21);
            this.Hid.TabIndex = 20;
            this.Hid.Text = "3020";
            this.Hid.TextChanged += new System.EventHandler(this.Hid_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(626, 329);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 17);
            this.label10.TabIndex = 21;
            this.label10.Text = "Price";
            // 
            // Cctv
            // 
            this.Cctv.Enabled = false;
            this.Cctv.Location = new System.Drawing.Point(754, 327);
            this.Cctv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Cctv.Name = "Cctv";
            this.Cctv.Size = new System.Drawing.Size(116, 21);
            this.Cctv.TabIndex = 22;
            this.Cctv.Text = "18990";
            this.Cctv.TextChanged += new System.EventHandler(this.Cctv_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(242, 128);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(250, 16);
            this.label11.TabIndex = 23;
            this.label11.Text = "VIBRAS 5.1 CH Surround Sound Xbox one / PC";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(246, 228);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(257, 16);
            this.label12.TabIndex = 24;
            this.label12.Text = "C6 H4 Led Headlight Bulbs lighting Conversion ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(246, 248);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(191, 16);
            this.label13.TabIndex = 25;
            this.label13.Text = "label13Kit High Low 36W / 3800LM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(242, 144);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 16);
            this.label14.TabIndex = 26;
            this.label14.Text = " Gaming Headset";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(249, 330);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(129, 16);
            this.label15.TabIndex = 27;
            this.label15.Text = "720p 6mm Cctv camera";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(725, 132);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(25, 17);
            this.label16.TabIndex = 28;
            this.label16.Text = "Rs.";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(728, 230);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(25, 17);
            this.label17.TabIndex = 29;
            this.label17.Text = "Rs.";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(728, 330);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(25, 17);
            this.label18.TabIndex = 30;
            this.label18.Text = "Rs.";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(83, 538);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 20);
            this.label19.TabIndex = 31;
            this.label19.Text = "Total :";
            this.label19.UseCompatibleTextRendering = true;
            // 
            // txtTotal
            // 
            this.txtTotal.Enabled = false;
            this.txtTotal.Location = new System.Drawing.Point(267, 536);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(116, 21);
            this.txtTotal.TabIndex = 32;
            this.txtTotal.TextChanged += new System.EventHandler(this.txtTotal_TextChanged);
            // 
            // btbContinue
            // 
            this.btbContinue.BackColor = System.Drawing.Color.White;
            this.btbContinue.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btbContinue.Location = new System.Drawing.Point(772, 524);
            this.btbContinue.Name = "btbContinue";
            this.btbContinue.Size = new System.Drawing.Size(139, 33);
            this.btbContinue.TabIndex = 33;
            this.btbContinue.Text = "Continue";
            this.btbContinue.UseVisualStyleBackColor = false;
            this.btbContinue.Visible = false;
            this.btbContinue.Click += new System.EventHandler(this.btbContinue_Click);
            // 
            // btnSignOut
            // 
            this.btnSignOut.BackColor = System.Drawing.Color.White;
            this.btnSignOut.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignOut.Location = new System.Drawing.Point(836, 21);
            this.btnSignOut.Name = "btnSignOut";
            this.btnSignOut.Size = new System.Drawing.Size(75, 23);
            this.btnSignOut.TabIndex = 34;
            this.btnSignOut.Text = "Sign out";
            this.btnSignOut.UseVisualStyleBackColor = false;
            this.btnSignOut.Visible = false;
            this.btnSignOut.Click += new System.EventHandler(this.btnSignOut_Click);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(52, 23);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(44, 17);
            this.lblName.TabIndex = 35;
            this.lblName.Text = "Name";
            this.lblName.Visible = false;
            this.lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // lblContinue
            // 
            this.lblContinue.AutoSize = true;
            this.lblContinue.ForeColor = System.Drawing.Color.Red;
            this.lblContinue.Location = new System.Drawing.Point(725, 564);
            this.lblContinue.Name = "lblContinue";
            this.lblContinue.Size = new System.Drawing.Size(11, 16);
            this.lblContinue.TabIndex = 36;
            this.lblContinue.Text = " ";
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.White;
            this.btnLogin.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(836, 23);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(75, 23);
            this.btnLogin.TabIndex = 37;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lbltxtCarlimit
            // 
            this.lbltxtCarlimit.AutoSize = true;
            this.lbltxtCarlimit.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltxtCarlimit.Location = new System.Drawing.Point(424, 418);
            this.lbltxtCarlimit.Name = "lbltxtCarlimit";
            this.lbltxtCarlimit.Size = new System.Drawing.Size(103, 16);
            this.lbltxtCarlimit.TabIndex = 38;
            this.lbltxtCarlimit.Text = "Remaining Limit :";
            this.lbltxtCarlimit.Visible = false;
            this.lbltxtCarlimit.Click += new System.EventHandler(this.lbltxtCarlimit_Click);
            // 
            // lblShowCardlimit
            // 
            this.lblShowCardlimit.AutoSize = true;
            this.lblShowCardlimit.Location = new System.Drawing.Point(547, 418);
            this.lblShowCardlimit.Name = "lblShowCardlimit";
            this.lblShowCardlimit.Size = new System.Drawing.Size(11, 16);
            this.lblShowCardlimit.TabIndex = 39;
            this.lblShowCardlimit.Text = " ";
            this.lblShowCardlimit.Visible = false;
            this.lblShowCardlimit.Click += new System.EventHandler(this.lblShowCardlimit_Click);
            // 
            // lbltxtCardRemainingBln
            // 
            this.lbltxtCardRemainingBln.AutoSize = true;
            this.lbltxtCardRemainingBln.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltxtCardRemainingBln.Location = new System.Drawing.Point(423, 448);
            this.lbltxtCardRemainingBln.Name = "lbltxtCardRemainingBln";
            this.lbltxtCardRemainingBln.Size = new System.Drawing.Size(117, 16);
            this.lbltxtCardRemainingBln.TabIndex = 40;
            this.lbltxtCardRemainingBln.Text = "Remaining Balance :";
            this.lbltxtCardRemainingBln.Visible = false;
            this.lbltxtCardRemainingBln.Click += new System.EventHandler(this.lbltxtCardRemainingBln_Click);
            // 
            // lblRmainingLimit
            // 
            this.lblRmainingLimit.AutoSize = true;
            this.lblRmainingLimit.Location = new System.Drawing.Point(547, 450);
            this.lblRmainingLimit.Name = "lblRmainingLimit";
            this.lblRmainingLimit.Size = new System.Drawing.Size(11, 16);
            this.lblRmainingLimit.TabIndex = 41;
            this.lblRmainingLimit.Text = " ";
            this.lblRmainingLimit.Click += new System.EventHandler(this.lblRmainingLimit_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.White;
            this.btnexit.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(826, 528);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(85, 30);
            this.btnexit.TabIndex = 42;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Visible = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(933, 580);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.lblRmainingLimit);
            this.Controls.Add(this.lbltxtCardRemainingBln);
            this.Controls.Add(this.lblShowCardlimit);
            this.Controls.Add(this.lbltxtCarlimit);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.lblContinue);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnSignOut);
            this.Controls.Add(this.btbContinue);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Cctv);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Hid);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Headset);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtWht);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtShipping);
            this.Controls.Add(this.SalesPrice);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.chkcctv);
            this.Controls.Add(this.chkHid);
            this.Controls.Add(this.chkhead);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox chkhead;
        private System.Windows.Forms.CheckBox chkHid;
        private System.Windows.Forms.CheckBox chkcctv;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox SalesPrice;
        private System.Windows.Forms.TextBox txtShipping;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtWht;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Headset;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Hid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Cctv;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Button btbContinue;
        private System.Windows.Forms.Button btnSignOut;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblContinue;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lbltxtCarlimit;
        private System.Windows.Forms.Label lblShowCardlimit;
        private System.Windows.Forms.Label lbltxtCardRemainingBln;
        private System.Windows.Forms.Label lblRmainingLimit;
        private System.Windows.Forms.Button btnexit;
    }
}

